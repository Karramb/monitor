CHOICES = (
        ('Blue', 'Голубой'),
        ('Gray', 'Серый'),
        ('Green', 'Зеленый'),
        ('Red', 'Красный'),
        ('Yellow', 'Желтый'),    
    )
MAX_LEN_STR_DEF = 20