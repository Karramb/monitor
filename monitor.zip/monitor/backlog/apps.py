from django.apps import AppConfig


class BacklogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backlog'
    verbose_name = 'бэклог'